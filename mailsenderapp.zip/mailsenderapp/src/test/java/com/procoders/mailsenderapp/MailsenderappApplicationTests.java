package com.procoders.mailsenderapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailsenderappApplicationTests {

	@Test
	void contextLoads() {
	}

}
