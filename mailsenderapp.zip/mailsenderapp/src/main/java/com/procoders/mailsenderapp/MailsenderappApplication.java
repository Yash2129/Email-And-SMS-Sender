package com.procoders.mailsenderapp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailsenderappApplication implements CommandLineRunner {

	@Value("${trialNumber}")
	String accountSid;
	public static void main(String[] args) {
		SpringApplication.run(MailsenderappApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(accountSid);;
	}

}
