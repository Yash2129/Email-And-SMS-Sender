package com.procoders.mailsenderapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.procoders.mailsenderapp.service.SendEmailService;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import org.springframework.web.bind.annotation.GetMapping;


@RestController
public class EmailController {

    @Value("${TWILIO_ACCOUNT_SID}")
    private String TwilioAccountSid;

    @Value("${TWILIO_AUTH_TOKEN}")
    private String TwilioAccountAuthToken;
    
    @Autowired
    private SendEmailService sendEmailService;

    @GetMapping("/sendEmail")
    public String sendEmail() {
        sendEmailService.sendEmailMethod("yashjoshi2129@gmail.com", "Test Body", "Test Subject");
        return "Sent Successfully";
    }
    
    @GetMapping("/sendSMS")
        public ResponseEntity<String> sendSMS() {

                Twilio.init(TwilioAccountSid,TwilioAccountAuthToken);

                Message.creator(new PhoneNumber("+918928455239"),
                                new PhoneNumber("+12564628099"), "Hello from Twilio 📞").create();

                return new ResponseEntity<String>("Message sent successfully", HttpStatus.OK);
        }
}
